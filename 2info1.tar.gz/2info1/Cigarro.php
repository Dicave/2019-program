<?php
print("Quantos cigarros voce fuma por dia: ");
$cigarros_dia = fgets(STDIN);

print("Quantos tempo voce demora para fumar 1 cigarro: ");
$tempo_cigarro = fgets(STDIN);

print(" ha quantos anos voce fuma:");
$anos_fumados = fgets(STDIN);



$tempo_dia_horas = $cigarros_dia * $tempo_cigarro /60;
$tempo_anos = $tempo_dia_horas * 365;
$dias_perdidos = $anos_fumados/24 ;
$minutos_perdidos = $tempo_dia_horas /60;

/*quantas horas e quantos dias  print(((10*365*3)11)/60)/24; ("FORMA simplificada") */
/*interpolar colocar variavel dentro do texto 
concatenar colocar variavel dentro dos parenteses 
round media para o meio se 4 = 5 SE 6 = 5
floor media baixa*/
?>