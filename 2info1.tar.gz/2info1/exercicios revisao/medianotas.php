<?php

print("nota media")
$i=1;
while( $i <= 5 ){

    
    echo $i;
    print ("informe a nota ");
    $notas  = (int) fgets(STDIN);

    $media = $notas +$media
    $media =$media/4
    $i++;

}
    



?>