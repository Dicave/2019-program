<?php


$contador = 1 ;

while ($contador <= 3 ) {
    
    print("$contador -");
    $contador = $contador +1 ; //se nao houver esta condiçao fica infinita
}


$contador = 0 ;

while ($contador < 0 ) {  # != 0 $num fgets(STDIN);
    
    print("$contador -");
    $contador = $contador -1 ;// $CONTADOR++ OU --
     //se nao houver esta condiçao fica infinita  
    sleep(1);
    //teorema macaco infinito escreva o livro do shawkspear
}


?>