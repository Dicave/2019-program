<?php   

// round aredonda para o mais perto 
// ceil aredonda para cima ceil=teto
// floor aredonda para baixo
// sqrt — Raiz quadrada


print("Calculador de 2 grau \n");

print("informe o Primeiro numero \n");
$a = fgets(STDIN);

print("informe o Segundo numero \n");
$b = fgets(STDIN);

print("informe o Terceiro numero \n");
$c = fgets(STDIN);

print("A = $a \n");
print("B = $b \n");
print("C = $c \n");

$delta = sqrt(-4*$a*$c);
print("delta: $delta");

$valor = pow($b,2);
print("$valor");

$x1 = $valor + $delta/2;
print("x1 = $x1");

$x2 = $valor - $delta/2;
print("x2 = $x2")

// $delta = pow($b,2)-4*$a*$c;
// $x1 = (-b +sqrt($delta)/2 *$a);
// $x1 = (-b +sqrt($delta)/2 *$a);

//bolean  2==2 
// var_dump tipo e o valor 
// || ou ou pipeline 
// && e e                               base  
// ipoteses 2 preposicoes elevar pow($preposicoes*2)  2² =4linhas prep tabela verdade

        // valor de:
// apresentar $a
// apresentar $b
// apresentar $delta
// apresentar $x1;
// apresentar $x2;

?>