<?php


// criar array $Lista = array[] OU $Lista = array('LUCAS')
// $Lista = array('ANA','Bia','Cassia');

// tipo de array
// array indexado
// array associativo
// array multidimensionais alunos tem caracteristicas diferentes 

$Herois = array('homo-aranha','vo-verine','pexe-da-agua');
// reṕita ate herois [4] = 0

// converter lista para texto
print_r($Herois);
var_dump($Herois);//mais detalhes 

//metacognichion malhar o cerebro
//academia dos deuses em casa corpo e mente

// $cont = 0;
// while($cont < 6 ){
//     $cont++;
//     while($Herois < 6 ){
//         print("$Herois[0]  ");
//         $Herois++ ;
//     }
    
// }
    //poderia colocar um personagem invisivel no array e começar o for do 1  
for ($i=0; $i <6; $i++) { 
    print($i + 1 . " lugar: . $Herois[$i] . " /n);
    
}

// adicionar uma pessoa na lista 
$Lista = array('ANA','Bia','Cassia');
$Lista[$variavel] = "Daniel";
//$Lista[1]="Heroi"
//$Lista[2]="Heroi"
//$Lista[3]="Heroi"
//$Lista[4]="Heroi"
//$Lista[] = //php coloca algo na ultima posiçao
    
count($Lista); //saber qual o proximo valor a ser adicionado

//Ordenar A Lista
//ordem de A-Z rsort($)
//desordem 
//tirar elemento da lista unset //reorganizar list 


for ($i=0; $i < count($Herois); $i++) { 
    print($i + 1 . " lugar: . $Herois[$i] . " /n);
    
}


?>