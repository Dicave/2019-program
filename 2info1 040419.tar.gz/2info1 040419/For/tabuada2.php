<?php


//TABUADA DO 2 EXEC 10
for ($j=2; $i <=10 ; $i++) { //executado 1 VEZ


    for ($i=0; $i <= 10 ; $i++) {  //executado 10 VEZ  //FAZ A primeira se for repetir novamente usar fro 
        print"$i \n";
        $calculo = $j * $i; 
    
        print("$tabuada x($i) =\n");
        
    
        // $leep(1);//observar o processo
        
    }
    print ("\n\n");
    

}
// $j = 2;//tabuada precisa ser repetida 
//BANCO DE DADOS consulta Lista de pessoas 1for nome dados 2 for 
//                        Lista



?>