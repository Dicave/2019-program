<?php

/* o "/" deixa a variavel como texto */

$a = 11;
$b = 33;


//troca
$a = $b;
$b = $a;

// swap de variaveis pyton pode se colocar mais de um valor para uma variavel

print("o valor de /$a e $a o valor de /$b e $b");
?>