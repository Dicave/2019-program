<?php

    print"Há quanto tempo você fuma?";
    $anos_fumados = fgets(STDIN);
    

    $cigarros_fumado  = 10*365*$anos_fumados;
    $minutos_perdidos = $cigarros_fumado * 11;
    $horas_perdidas   = $minutos_perdidos/60;
    $dias_perdidos    = round($horas_perdidas/24);
    
    print "Você perdeu $dias_perdidos dias de vida";
