<?php
print "--------Soma---------\n";

print("informe o primeiro numero:");
$a  = (int) fgets(STDIN);

print("informe o segundo numero:");
$b  = (int) fgets(STDIN);

$media =$a + $b;

print("o resultado da soma e: $media");

?>