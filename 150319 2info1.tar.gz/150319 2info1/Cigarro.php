<?php
print("Quantos cigarros voce fuma por dia: \n");
$cigarros_dia = fgets(STDIN);

print("Quantos tempo voce demora para fumar 1 cigarro: \n");
$tempo_cigarro = fgets(STDIN);

print(" ha quantos anos voce fuma: \n");
$anos_fumados = fgets(STDIN);






$cigarros_dia = $cigarros_dia * $tempo_cigarro ;
$tempo_ano = ($cigarros_dia * 365 *$anos_fumados) ; //anos fumados /horas 60//tempo /dias //tempo em minutos perdido em 1 ano
$horas_perdidos = $tempo_ano/60;
$dias_perdidos = $horas_perdidos/24;



// print("$cigarros_dia \n");
// print("$tempo_ano \n");
// print("$horas_perdidos \n");
// print("$dias_perdidos \n");

print("Voce perde por dia : $cigarros_dia min  \n");
print("Voce perdeu cerca de : $dias_perdidos dias por ano\n");




/*quantas horas e quantos dias  print(((10*365*3)11)/60)/24; ("FORMA simplificada") */
/*interpolar colocar variavel dentro do texto 
concatenar colocar variavel dentro dos parenteses 
round media para o meio se 4 = 5 SE 6 = 5
floor media baixa*/
?>