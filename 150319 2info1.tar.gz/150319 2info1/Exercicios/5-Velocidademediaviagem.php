<?php

print("-----------------------------\n");
print("       Tempo de viagem       \n");
print("-----------------------------\n");

print("informe a distancia que sera percorrida KM:\n");
$KM = fgets (STDIN);

print("Informe a velocidade media que sera percorrido:\n");
$Velocidade = fgets (STDIN);

$tempo = $KM / $Velocidade;

// print($tempo);
if($tempo < 0.99){
    print("seu percurso sera feito em Minutos/segundos \n");
    print("Tempo $tempo");

}elseif($tempo > 0.99){
    print("seu percurso sera feito em: \n");
    print("Hora/Minutos $tempo");    

}
?>