<?php 
print("-----------------------------\n");
print("Conversor tempo em segundos\n");
print("-----------------------------\n");

print("Informe as Horas:\n");
$Horas = fgets (STDIN);

print("Informe os Minutos:\n");
$Minutos = fgets(STDIN);

print("Informe os segundos:\n");
$Segundos = fgets(STDIN);

print("Convertendo\n");
print("Horas : $Horas Minutos : $Minutos Segundos : $Segundos ");
print("Em segundos Fica:");

$Horas = $Horas *60; 
// print("$Horas");
$Minutos = $Minutos + $Horas *60;
// print("$Minutos");
$Segundos =$Segundos + $Minutos;
// print("$Segundos");

print("Segundos : $Segundos ");

?>