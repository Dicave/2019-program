<?php

print("-----------------------------\n");
print("   Celcius para fahrenheit   \n");
print("-----------------------------\n");

print("informe a Temperatura em Celsius (°C) :\n");
$Celcius = fgets (STDIN);

$Fahrenheit = ($Celcius * 9/5) + 32 ;
// :print($Fahrenheit);
print("A temperatura em Fahrenheit (°F) fica: $Fahrenheit °F\n");



?>