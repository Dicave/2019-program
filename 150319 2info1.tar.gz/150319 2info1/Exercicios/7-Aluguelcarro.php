<?php   
print("-----------------------------\n");
print("        Aluguel carro        \n");
print("-----------------------------\n");

print("informe quantos Km foi percorrido pelo carro alugado:\n");
$KM = fgets (STDIN);

print("Informe por quantos dias o carro foi alugado:\n");
$Dias = fgets (STDIN);

$Valor_km = $KM * 0.15;
$Valor_dia = $Dias * 60;
print("$Valor_km\n");
print("$Valor_dia\n");

$Total_diaria = $Valor_dia + $Valor_km;

print("Diaria custou : $Valor_dia R$ \n");
print("    Km custou : $Valor_km  R$ \n");
print("        Total = $Total_diaria R$ \n");
?>