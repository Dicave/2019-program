<?php

print("-----------------------------\n");
print("     Desconto mercadoria     \n");
print("-----------------------------\n");

print("informe o valor do produto :\n");
$Preco = fgets (STDIN);

print("Informe quantos porcento % sera o desconto:\n");
$desconto = fgets (STDIN);

$valor_desconto = $Preco /100 *$desconto ;
// print($valor_desconto);

$Preco = $Preco - $valor_desconto; 
// print($Preco);

print("Seu desconto é de: $valor_desconto \n");
print("Valor total a pagar:$Preco \n");
?>