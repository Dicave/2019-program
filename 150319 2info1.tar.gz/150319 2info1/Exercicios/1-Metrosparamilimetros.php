<?php 

print(" ----------Conversor----------\n");
print("    Metros   para   Milimetro \n");


print("Informe quantos metros quer converter para milimetro:");
$metros = fgets(STDIN);

$multi =1000 ;
$milimetros = $metros * $multi;  

                                             

print(" convertendo: $metros    metros  = $milimetros  Milimetros  \n");

//            modulo
// resto %     8 % 2 =0 dividindo 8 por 2 resto 
//                           pode se saber se é impar ou par

?>