<?php
// print("informe os metros quadrados a ser pintado:");
// $area = fgets(STDIN);

$area =108;

$lata_rendimento =108;//18*6
$lata_preco = 80;

$galao_rendimento =21.6 ;//13.6*6
$galao_preco = 25; 

#a comprar apenas com latas de 18 litros pintando 109m
$qtd_latas =ceil($area / $latas_rendimento);
//para saber quantas latas preciso para pintar a sobra tera que ser aredondada para cima 
print $qtd_latas;

#b comprar apenas com galoes de 3,6 litros
$qtd_galao = ceil($area / $galao_rendimento );
$galao_rendimento =

#c comprar com o melhor custo beneficio

//ate 3 galoes fica mais barato que 1 lata 
//130m usa 1 lata e 1 galao
$qtd_latas = (int)($area / $lata_rendimento);
$faltou_lata = fmod($area % $galao_rendimento);
$qtd_galao =ceil($faltou_lata / $galao_rendimento);

print ("$faltou_lata -$qtd_galao")
//usar operador de modulo que pega o resto fmod()
// diminuir a quantidade exata de lata que for dada para pintar 109m pegar o resto ecomprar galao

?>

