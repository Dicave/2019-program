<?php

print("Informe o valor do primeiro lado do triangulo :");
$a = fgets (STDIN);

print("Informe o valor do segundo lado do triangulo :");
$b = fgets (STDIN);

print("Informe o valor do terceiro lado do triangulo:");
$c = fgets (STDIN);

// diferente <> = !=
// condiçao de existencia triangulo 
if($a + $b > $c and $a + $c > $b and $b + $c > $a){

    if ($a == $b and $b == $c and $c == $a) {
    print("Triângulo equilátero");

    }elseif($a != $b and $b != $c and $c != $a) {
    print("Triângulo escaleno");
    
    }else{
    print("Triângulo isósceles");
    
    }
}

// Triângulo equilátero: possui os três lados com medidas iguais. 
// Triângulo isósceles: possui dois lados com medidas iguais. 
// Triângulo escaleno: possui os três lados com medidas diferentes. 





?>