<?php


print("Informe o nome de seu cachorro:");
$nome_cachorro = fgets (STDIN);

print("Informe o peso de seu cachorro:");
$peso_cachorro = fgets (STDIN);

if($peso_cachorro = 2){
    print("esse cachorro late fino: au au au \n");

}elseif($peso_cachorro = 10){
    print("esse cachorro tem um belo latido \n");                     //
                                                                        //elseif
    }else{ //($peso_cachorro > 10) junta os dois e se forma o elseif  //
        print("esse cachorro late grosso: woof, woof \n");
}



// switch($opçao)

 
//uma lista que ja existe 
// uma ou outra opçao que pode ser feita

// Triângulo equilátero: possui os três lados com medidas iguais. 
// Triângulo isósceles: possui dois lados com medidas iguais. 
// Triângulo escaleno: possui os três lados com medidas diferentes. 

?>