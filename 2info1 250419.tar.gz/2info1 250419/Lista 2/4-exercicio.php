<?php

print("Informe uma Letra:");
$tex =fgets(STDIN);


  $letra = '$tex';
  switch (strtoupper($letra)){
    case 'A':
    case 'E':
    case 'I':
    case 'O':
    case 'U':
      echo ("Esta letra é uma vogal");
      break;
    default:
      echo ("Esta letra é uma consoante");
      break;
  }

$num =['1','1';'1']
                        //guarda monstra 
foreach ($variable as $valor => $valor) {
    # code...
}
?>