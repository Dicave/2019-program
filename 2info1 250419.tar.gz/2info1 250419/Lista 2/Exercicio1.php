<?php

print("----------------------------  \n");
print("        Maior Numero          \n");
print("----------------------------  \n");

print("Informe o Primeiro numero: \n");
$n1 = fgets(STDIN);

print("Informe o Swgundo numero: \n");
$n2 = fgets(STDIN);

if($n1 >$n2){
    print("Primeiro numero e o maior:$n1 \n");
    }else{
        print("Segundo numero e o maior:$n2 \n");
    }


// if ($n1 > $n2){
//     print("O maior numero e :$n1");
// }
// if($n2>$n1){
//     print("O maior numero e :$n2");
// }


?>