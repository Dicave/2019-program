<?php
print("----------------------------  \n");
print("    Positivo e Negativo       \n");
print("----------------------------  \n");
print("Informe a Primerira nota: ");
$n1 =fgets(STDIN);

print("Informe a Segunda nota: ");
$n2 =fgets(STDIN);

print("Informe a Terceira nota: ");
$n3 =fgets(STDIN);

print("Informe a Quarta nota: ");
$n4 =fgets(STDIN);


$media = (n1+n2+n3+n4)/4;

if($media==10){
    print("Aprovado com Distinção");

}

if($meida>7){
    print("Aluno Aprovado");

}else{
    print("Aluno Reprovado");
}


?>