<?php


$contador = 0;

while($contador < 11 ){

    if($nota != -1 and $nota < 11){
        print("Informe uma nota entre 0 e 10 :");
        $nota = fgets(STDIN);
        $contador = $contador +1;
    }
}

// correçao

$nota = (INT) fgets(STDIN);

while($nota < 0 or $nota > 10){
    print("valor invalido");

    print("Informe uma nota:");
    $nota = fgets(STDIN);

}


// Do while
do{ 
    print("Informe uma nota:");
    $nota = fgets(STDIN);

}while($nota < 0 or $nota > 10); //executar pelo menos uma vez 
                                    //$variavel rand (1,10) sorteio de um num 
?>