<?php



function digaOla($nome){//toda variavel que e executada precisa ser informada
    



}//ao terminar variavel e destruida na memoria

digaOla()//se colocar um valor aqui

function Cartaotrab(string $nome,$email){
    print("===========================");
    print("| $nome                 \n|");
    print("| $email                \n|");
    print("===========================");
    
}
$nome = Fgets(STDIN);


Cartaotrab("$nome,$email")

//a ponte e o infeliz
//Fgets Fgetc somente caractere
// function validarCPF($cpf)
//validarCPF()
// contra fatos nao ha argumentos 

?>