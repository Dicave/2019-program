<?php

print("nota media");


while( $i <= 5 ){ 
        
echo $i (":nota" );
print ("informe a nota ");
$notas  = (int) fgets(STDIN);

$media = $notas +$media;
$media =$media/4;
 $i++;

}
    



?>