<?php

// tipos primitivos 4 "existe os complexos a partir do mes 6 /saber o tipo da variavel 'variavel'chamada var_dump();
// sql injection pegar sites e fazer teste //cqc programa esquema de votar pelo computador algoritmo para votar com repita= FOR

// decimal(interger) tem um limite php_int_max;(windows mais limitado que linux (mais robusto)
// real(float) ou (double)(dobro php nao mostra) sqrl(4) (potencia)
// texto (sting)
// logico (bolean) isc_bool($variavel) validar formularios

$maior_idade = false;
var_dump($maior_idade);


// e = AND ->&&
// ou = OR ->||
    // 18                                      1,49
 if (idade"BOOLEAN verdadeiro ou falso" >=8 or  altura >=1,50);

$cidade ='araquari'; //aspas simples valor literal (codigo mais rapido) "aspas duplas encontra variavel 
 print $cidade[0];
 print $cidade[1];


dinamicamente tipado $nome = "joao" $nome = "10"

/*
$nome_usuario = 'Meu nome';
$lote = 87;
$sim = true;
$valor = 1.14;
  
//variavel dinamica
$nome = 'variavel';    
$nome = 'meu valor'; 
  
var_dump($nome_usuario);
echo "<br>";
var_dump($lote);
echo "<br>";
var_dump($sim);
echo "<br>";
var_dump($valor);
echo "<br>";
var_dump($variavel);
*/
?>