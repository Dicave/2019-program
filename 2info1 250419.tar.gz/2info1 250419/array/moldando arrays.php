<?php


$herois("Batman","Hulk","Thor","Kratos");

// tirar elemento da lista 
// adicionar
// %agenda =[123  @GMAIL
//Array 
$fruta = array (
    "cor" =>"vermelha";
   "chave"  => "valor";
   "formato"  =>"redonda";
   "nome" => "maça";
)

// $array = array (
//     "cor" =>"vermelha";
//    "chave"  => "valor";
//    "formato"  =>"redonda";
//    "nome" => "maça";
// 
// 

//percorrer list foreach para cada elemento bpim

foreach($fruta as $ propiedade)
  
foreach ($herois as $key => $herio) {
    print("Qual o valor do heroi")
} 

//X debug
 


?>