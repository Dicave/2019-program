<?php 

print(" ----------Conversor----------\n");
print("  metros para milimetro \n");


print("Informe quantos metros quer converter para milimetro: \n");
$metros = fgets(STDIN);

$milimetros = $metros*1000;

print("$metros  = $milimetros  Milimetros \n");

//            modulo
// resto %     8 % 2 =0 dividindo 8 por 2 resto 
//                           pode se saber se é impar ou par

?>