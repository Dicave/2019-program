<?
print("Informe 5 caracteristicas para algo")



?>