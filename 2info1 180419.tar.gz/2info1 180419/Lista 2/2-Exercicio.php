<?php
print("----------------------------  \n");
print("    Positivo e Negativo       \n");
print("----------------------------  \n");
print("Informe um numero");
$num =fgets(STDIN);

if(){
    
}


?>