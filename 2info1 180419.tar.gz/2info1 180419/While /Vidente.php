<?php

print("The game best : \n");
$sorteio = rand(1,10);
$numsorte = $sorteio;



do{ 
    print("Informe um numero :");
    $num = fgets(STDIN);
    
}while($num < 0 or $num > 10);

if($numsorte = $num){
    print("Voce e um vidente");
}




?>