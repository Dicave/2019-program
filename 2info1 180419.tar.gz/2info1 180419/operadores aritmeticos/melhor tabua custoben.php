<?php   

print("comparando tabuas\n");
print("informe o tamanho das partes que vao ser cortadas:\n");
$tamanho_corte = fgets(STDIN);
$tamanho_corte = $tamanho_corte/10;

print("informe o tamanho da 1 tabua:\n");
$primeira_tabua = fgets(STDIN);


$primeira_tabua = $primeira_tabua*10;   
$sobra = $primeira_tabua % $tamanho_corte;
$pedacos = $primeira_tabua / $tamanho_corte - $sobra;


print("uma tabua com $primeira_tabua metros;\n");
print("E possivel cortar $pedacos;\n");
print("e tera o desperdicio de $sobra;\n");

// -------------------------------------------------- //
print("informe o tamanho da 2 tabua:\n");
$segunda_tabua = fgets(STDIN);


$segunda_tabua = $segunda_tabua*10;   
$sobra = $segunda_tabua % $tamanho_corte;
$pedacos = $segunda_tabua / $tamanho_corte - $sobra;


print("uma tabua com $segunda_tabua metros:\n");
print("E possivel cortar $pedacos:\n");
print("e tera o desperdicio de $sobra:\n");

// -------------------------------------------------- //

print("informe o tamanho da 3 tabua:");
$terceira_tabua = fgets(STDIN);


$terceira_tabua = $terceira_tabua*10;   
$sobra = $terceira_tabua % $tamanho_corte;
$pedacos = $terceira_tabua / $tamanho_corte - $sobra;


print("uma tabua com $terceira_tabua metros:");
print("E possivel cortar $pedacos:");
print("e tera o desperdicio de $sobra:");


// -------------------------------------------------- //



print_r("");

?>