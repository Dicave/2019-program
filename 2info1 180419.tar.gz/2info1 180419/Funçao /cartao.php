<?php

function Cartao(){
    print("Wesley Antunes Negretti 17y \n");
    print("Estudante: Ensino Medio \n");
    print("Bairro: João Costa   Rua:Antidio Paulo gesser  n:389 \n");
}

function Cartaotrab(){
    print("===========================");
    print("| Wesley Antunes        \n|");
    print("| wesleyssteam@gmail.com\n|");
    print("===========================");
    
}
function datahora(){
    
}



?>