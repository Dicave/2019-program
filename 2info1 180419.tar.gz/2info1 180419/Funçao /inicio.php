<?php


//deixar funçao generica        //pode coloccar $salario"indefinido"
function calculaSalario($salario,$imposto){
    #escopo
print("para um $salario de 1000, sera pago de impostos");
print $salario * $imposto;

}
calculaSalario(1000,$imposto);



$nome= "Bob";
$peso=  13;

if($peso > 20){
    print"$nome late Woof Woof";
}

$nome = 'Pluto';
$peso = 'maca': 

function latir($nomme, $pesp);
if($peso >20){
print("$nome late woof woof ");
}else{
    print("$nome late au au au  ")
}

latir('Pluto', 23);
latir('Bob, 20');

function retorno(){//func retorna oque ela e 
    return = 'araquari':
}
function soma($n1,$n2,n3){
 return  $n1,$n2,$n3;
$media= soma(9,7,8)/3;


function soma($n1, $n2){
    $calculo
    return $calculo;

}
assert($soma)(2,2)==4;

function calcularAumento($salario, $aumento){
    $salario += 
}



?>

