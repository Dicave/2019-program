<?php

function digaOla(){
    print("Olá");

}
//executa quando necessario dispara funçao que chama essa funçao 
//importar arquivos quando a funçao chamar
//aprender a usar o composer 
digaOla();






?>