<?php
//Wesley
//2info1 
//21/03/19
// while enquanto nao colocar a senha correta nao sera aceito 
// enquanto a senha for errada vai repetir nao da pra saber quantas vezes ira errar
//for e um while oreganizado nem tudo que quiser fazer com for consegue com while (nem tudo com for ) 

for($i = 0; $i<10;$i++){
    print $i
    if(condiçao){

    }
}

for($i = 0; $i<1000;$i++){
    print $i
    if($i == 777){
    print(ache o num 777)
    break//para a repetiçao
        
    }
}

for($i = 0; $i<1000;$i++){
    if($i > 50 && $i<60){ //&& and igual
        continue://nao termina de executar o cod executa do inicio novamente
    }
    print $i;
}




// algoritmo linear 1 ao 10 
?>