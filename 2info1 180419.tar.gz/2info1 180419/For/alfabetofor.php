<?php

print("Fatorial de um num multiplicado por o antecessor 5!");

$fatorial = 5;
// 5! = 5.4.3.2.1 =180
for ($i=1; $i <=4 ; $i++) { 

    $antecessor = $fatorial -1;
    $fatorial = $fatorial * $antecessor;


}
// fazer exercicios

?>